import React from 'react';

const Todo = ({ title, todos, setTodos, todo }) => {
    const deleteHandler = () => {
        setTodos(todos.filter((item) => item.id !== todo.id))
    }

    const completedHandler = () => {
        setTodos(todos.map((item) => {
            if(item.id === todo.id){
                return{
                    ...item, completed: !item.completed
                }
            }
            return item 
        }))
    }

    const importantHandler = () => {
        setTodos(todos.map((item) => {
            if(item.id === todo.id){
                return{
                    ...item, important: !item.important
                }
            }
            return item 
        }))
    }

    return (
        <div>
            <li className={`${todo.important ? 'important' : ''}  ${todo.completed ? 'completed' : ''} `}>{title}</li>
            <button onClick={deleteHandler}>Delete</button>
            <button onClick={completedHandler} >Completed</button>
            <button onClick={importantHandler}>Important</button>

        </div>
    )
}

export default Todo;